import json
from pathlib import Path
import verify as v

original = json.loads((v.WORK / "results.json").read_text())
# verify's helpers emit a fresh supplemental list, later merged by case name.
v.invoke("supplement.provider.refresh", ["config", "add", "model-provider", "verify", v.BASE])
v.invoke("chat.persist_preferences", ["chat", "--set-ax-screen-reader", "--set-ax-bell", "false", "--set-default-model", "system"])
v.invoke("chat.persist.model_readback", ["config", "get", "default-model"],
         check=lambda out, err: v.require(out.strip() == "system", "default model did not persist"))
v.invoke("chat.persist_no_ax", ["chat", "--set-no-ax-screen-reader", "--set-ax-bell", "true", "--set-default-model", "pcc"])
v.invoke("chat.persist.pcc_readback", ["config", "get", "default-model"],
         check=lambda out, err: v.require(out.strip() == "pcc", "default model did not persist"))
v.invoke("chat.reject_mixed_set", ["chat", "--set-default-model", "system", "-m", "cap-model"], reject=True)
v.chat("chat.no_ax_renderer", inputs=("hi", "/quit"), ax=False)
model = v.chat("chat.runtime.model_named", inputs=("/model cap-model", "hi", "/quit"), provider="verify")
if "Unknown model" in model["stdout"]:
    model["status"] = "FAIL"
    model["reason"] = "The active custom model is not selectable via /model."
for tool, image, expected in [("ocr", "ocr.png", "FM VERIFY 12345"), ("barcode", "qr.png", "FM-VERIFY-QR-12345")]:
    v.respond("respond.tool." + tool, ["--tool", tool, "--image", str(v.WORK / image)],
              prompt="extract text", timeout=30,
              check_request=lambda req, expected=expected: v.require(
                  expected in json.dumps(req["body"]), "actual recognition result not forwarded"))
v.respond("respond.image_labels", ["--tool", "ocr", "--image", str(v.WORK / "ocr.png"),
                                  "--label", "text", "--image", str(v.WORK / "qr.png"), "--label", "barcode"],
          prompt="describe", timeout=30,
          check_request=lambda req: v.require(
              json.dumps(req["body"]).count("data:image/jpeg;base64,") == 2, "labelled images missing"))
v.record("config.user_unchanged", "PASS" if v.hashlib.sha256(v.USER_CONFIG.read_bytes()).hexdigest() == v.ORIGINAL_HASH else "FAIL",
         ["sha256", "~/.fm/config.json"])
v.server.shutdown()
merged = {r["name"]: r for r in original}
merged.update({r["name"]: r for r in v.RESULTS})
rows = list(merged.values())
(v.WORK / "results.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False))
print(json.dumps({status: sum(r["status"] == status for r in rows)
                  for status in sorted({r["status"] for r in rows})}), flush=True)
