import AppKit
import CoreImage

let folder = CommandLine.arguments[1]
let textImage = NSImage(size: NSSize(width: 640, height: 180))
textImage.lockFocus()
NSColor.white.setFill()
NSRect(x: 0, y: 0, width: 640, height: 180).fill()
("FM VERIFY 12345" as NSString).draw(at: NSPoint(x: 30, y: 60), withAttributes: [
    .font: NSFont.systemFont(ofSize: 48),
    .foregroundColor: NSColor.black
])
textImage.unlockFocus()
let textRep = NSBitmapImageRep(data: textImage.tiffRepresentation!)!
try textRep.representation(using: .png, properties: [:])!.write(
    to: URL(fileURLWithPath: folder + "/ocr.png"))

let generator = CIFilter(name: "CIQRCodeGenerator")!
generator.setValue(Data("FM-VERIFY-QR-12345".utf8), forKey: "inputMessage")
generator.setValue("H", forKey: "inputCorrectionLevel")
let qr = generator.outputImage!.transformed(by: CGAffineTransform(scaleX: 12, y: 12))
let qrRep = NSBitmapImageRep(cgImage: CIContext().createCGImage(qr, from: qr.extent)!)
try qrRep.representation(using: .png, properties: [:])!.write(
    to: URL(fileURLWithPath: folder + "/qr.png"))
print("created ocr.png and qr.png")
