import json
import verify as v

previous = json.loads((v.WORK / "results.json").read_text())
earlier = next(r for r in previous if r["name"] == "respond.tool.ocr")
v.respond("respond.tool.ocr", ["--tool", "ocr", "--image", str(v.WORK / "ocr.png")],
          prompt="extract text", timeout=30,
          check_request=lambda req: v.require("FM VERIFY 12345" in json.dumps(req["body"]),
                                              "OCR result missing"))
v.server.shutdown()
merged = {r["name"]: r for r in previous}
merged.update({r["name"]: r for r in v.RESULTS})
merged["respond.tool.ocr"]["earlier_attempt"] = {
    "status": earlier["status"], "duration_s": earlier.get("duration_s"),
    "stdout": earlier.get("stdout"), "stderr": earlier.get("stderr")}
(v.WORK / "results.json").write_text(json.dumps(list(merged.values()), indent=2, ensure_ascii=False))
