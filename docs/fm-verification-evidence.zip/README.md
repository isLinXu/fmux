# fm 验证证据包

`results.json` 是补测、复测合并后的最终 95 项矩阵，优先以此为准。
`live-results.json` 是真实本地模型调用结果。其他日志包含历史尝试、
测试假设修正与首次初始化超时，不能直接拿历史日志的计数当最终结论。

脚本仅适用于当前 macOS fm 安装与 `/Users/linxu/projects/fmux` workspace。
`verify.py` 复用 workspace 中 `scripts/capture_fm.py` 的 schema/fixture 帮助函数，
创建本机临时可控提供商，配置使用证据包目录下的隔离 HOME。
许可确认只读取，不做接受操作；不执行 PCC 云端生成。

如需复测，顺序是 `verify.py`、`supplement.py`、`finish.py`。
测试图片已包含；`make_images.swift` 可重新生成。
`live_verify.py` 是独立的真实推理测试，会访问当前用户的默认 fm 配置
及本机现有 fmux/Qwen，可能占用 GPU；每次调用上限为 35 秒。
结果不是对其他机器、系统版本或模型的保证。

Vision 首次初始化可能很慢；`probe_vision.swift` 是独立识别诊断，
本次最终识别出了 `FM VERIFY 12345` 和 `FM-VERIFY-QR-12345`。
