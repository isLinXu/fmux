import Foundation
import Vision

let folder = CommandLine.arguments[1]
let text = VNRecognizeTextRequest()
text.recognitionLevel = .accurate
try VNImageRequestHandler(url: URL(fileURLWithPath: folder + "/ocr.png")).perform([text])
let lines = (text.results ?? []).compactMap { $0.topCandidates(1).first?.string }
print("ocr=" + lines.joined(separator: "|"))
let barcode = VNDetectBarcodesRequest()
try VNImageRequestHandler(url: URL(fileURLWithPath: folder + "/qr.png")).perform([barcode])
print("barcode=" + (barcode.results ?? []).compactMap { $0.payloadStringValue }.joined(separator: "|"))
