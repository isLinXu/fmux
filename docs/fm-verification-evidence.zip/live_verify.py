import json
from pathlib import Path
import subprocess
import time
import urllib.request

WORK = Path(__file__).parent
results = []


def run(name, args, timeout=35):
    started = time.monotonic()
    p = subprocess.Popen(["/usr/bin/fm", *args], stdin=subprocess.DEVNULL,
                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    timed_out = False
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        p.terminate()
        try:
            out, err = p.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            p.kill()
            out, err = p.communicate()
    status = "TIMEOUT" if timed_out else ("PASS" if p.returncode == 0 and out.strip() else "FAIL")
    row = dict(name=name, command=args, status=status, returncode=p.returncode,
               duration_s=round(time.monotonic()-started, 3), stdout=out, stderr=err)
    results.append(row)
    print(f"{status} {name} {row['duration_s']}s", flush=True)
    (WORK / "live-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False))


run("live.original_swift", ["respond", "What is Swift?"])
run("live.short_buffered", ["respond", "--model-provider", "fmux", "-m", "qwen-fast",
                            "--no-stream", "-i", "Answer with exactly OK, without reasoning.",
                            "Say OK. /no_think"])
person = WORK / "live-person.json"
person.write_text(json.dumps({"type": "object", "title": "Person", "properties": {
    "name": {"type": "string"}, "age": {"type": "integer"}},
    "required": ["name", "age"], "additionalProperties": False}))
run("live.structured", ["respond", "--model-provider", "fmux", "-m", "qwen-json",
                       "--no-stream", "--schema", str(person), "Name is Ada; age is 36. /no_think"])
run("live.models", ["models", "--model-provider", "fmux"], timeout=5)
with urllib.request.urlopen("http://127.0.0.1:11434/api/ps", timeout=3) as response:
    (WORK / "live-backend.json").write_bytes(response.read())
