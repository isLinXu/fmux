"""One-off verification of the installed fm CLI, with an isolated configuration."""
import hashlib
import fcntl
import importlib.util
import io
import json
import os
from pathlib import Path
import pty
import select
import signal
import socket
import subprocess
import struct
import sys
import termios
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

ROOT = Path("/Users/linxu/projects/fmux")
WORK = Path(__file__).parent
HOME = WORK / "home"
HOME.mkdir(exist_ok=True)
ENV = dict(os.environ, HOME=str(HOME), CFFIXED_USER_HOME=str(HOME), TERM="xterm-256color")
RESULTS = []
REQUESTS = []
LOCK = threading.Lock()
USER_CONFIG = Path("/Users/linxu/.fm/config.json")
ORIGINAL_HASH = hashlib.sha256(USER_CONFIG.read_bytes()).hexdigest()
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location("capture", ROOT / "scripts/capture_fm.py")
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)


def record(name, status, command, stdout="", stderr="", **extra):
    row = dict(name=name, status=status, command=command, stdout=stdout[-24000:],
               stderr=stderr[-12000:], **extra)
    RESULTS.append(row)
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print(f"{status:11} {name}", flush=True)
    return row


def invoke(name, args, check=None, reject=False, timeout=8, stdin=None, blocked=False):
    started = time.monotonic()
    proc = subprocess.Popen(["/usr/bin/fm", *args], stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, env=ENV, cwd=WORK, start_new_session=True)
    try:
        out, err = proc.communicate(stdin, timeout=timeout)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            out, err = proc.communicate(timeout=2)
        except subprocess.TimeoutExpired:
            proc.kill()
            out, err = proc.communicate()
        return record(name, "TIMEOUT", args, out, err, duration_s=time.monotonic()-started)
    status = "PASS"
    reason = ""
    if reject:
        if proc.returncode == 0:
            status, reason = "FAIL", "invalid input was accepted"
    elif proc.returncode != 0:
        status = "BLOCKED" if blocked else "FAIL"
        reason = f"exit={proc.returncode}"
    if status == "PASS" and check:
        try:
            check(out, err)
        except Exception as exc:
            status, reason = "FAIL", str(exc)
    return record(name, status, args, out, err, returncode=proc.returncode,
                  reason=reason, duration_s=time.monotonic()-started)


def require(value, message):
    if not value:
        raise AssertionError(message)


def sanitize(req):
    raw = json.dumps(req)
    obj = json.loads(raw)
    for message in obj.get("messages", []):
        content = message.get("content")
        if isinstance(content, list):
            for part in content:
                image = part.get("image_url", {})
                url = image.get("url", "")
                if url.startswith("data:"):
                    image["url"] = url[:40] + f"...[length={len(url)}]"
    return obj


class Provider(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def send(self, code, ctype, body):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path.rstrip("/").endswith("/models"):
            self.send(200, "application/json", json.dumps({"object": "list", "data": [
                {"id": "cap-model", "object": "model", "owned_by": "verification"}]}).encode())
        else:
            self.send(200, "text/plain", b"ok")

    def do_POST(self):
        req = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
        with LOCK:
            REQUESTS.append({"body": req, "path": self.path,
                             "headers": {k: v for k, v in self.headers.items()
                                         if k.lower() in ("x-fm-verify", "x-extra", "user-agent")}})
        if req.get("model") == "error-model":
            self.send(503, "application/json", b'{"error":{"message":"verification unavailable","type":"server_error","code":"unavailable"}}')
            return
        text = capture.reply_for(req)
        tool_messages = [m for m in req.get("messages", []) if m.get("role") == "tool"]
        has_image = any("image_url" in json.dumps(m) for m in req.get("messages", []))
        tool_call = None
        if req.get("tools") and has_image and not tool_messages:
            function = req["tools"][0]["function"]
            labels = function["parameters"]["$defs"]["ImageReference"]["properties"]["attachmentLabel"]["enum"]
            tool_call = {"index": 0, "id": "verify-tool-1", "type": "function",
                         "function": {"name": function["name"],
                                      "arguments": json.dumps({"image": {"attachmentLabel": labels[0]}})}}
        if tool_messages:
            text = "pong: " + json.dumps([m.get("content") for m in tool_messages])
        if req.get("stream"):
            chunks = [
                {"id": "chatcmpl-verify", "object": "chat.completion.chunk", "created": 1700000000,
                 "model": req.get("model"), "choices": [
                     {"index": 0, "delta": {"role": "assistant", "content": text}, "finish_reason": None}]},
                {"id": "chatcmpl-verify", "object": "chat.completion.chunk", "created": 1700000000,
                 "model": req.get("model"), "choices": [
                     {"index": 0, "delta": {}, "finish_reason": "stop"}]},
                {"id": "chatcmpl-verify", "object": "chat.completion.chunk", "created": 1700000000,
                 "model": req.get("model"), "choices": [],
                 "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4}}
            ]
            if tool_call:
                chunks[0]["choices"][0]["delta"] = {"role": "assistant", "tool_calls": [tool_call]}
                chunks[1]["choices"][0]["finish_reason"] = "tool_calls"
            body = "".join("data: " + json.dumps(ch) + "\n\n" for ch in chunks) + "data: [DONE]\n\n"
            self.send(200, "text/event-stream", body.encode())
        else:
            self.send(200, "application/json", json.dumps({
                "id": "chatcmpl-verify", "object": "chat.completion", "created": 1700000000,
                "model": req.get("model"), "choices": [{"index": 0,
                    "message": {"role": "assistant", "content": text}, "finish_reason": "stop"}],
                "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4}}).encode())


server = ThreadingHTTPServer(("127.0.0.1", 0), Provider)
threading.Thread(target=server.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{server.server_port}/v1"


def respond(name, extra=None, prompt="hi", check_request=None, expected="pong", stdin=None, model="cap-model", timeout=8):
    before = len(REQUESTS)
    args = ["respond", "--model-provider", BASE, "-m", model, *(extra or [])]
    if prompt is not None:
        args.append(prompt)
    def check(out, err):
        require(expected in out, "expected response absent")
        require(len(REQUESTS) > before, "provider did not receive request")
        if check_request:
            check_request(REQUESTS[-1])
    row = invoke(name, args, check=check, stdin=stdin, timeout=timeout)
    if len(REQUESTS) > before:
        row["request"] = sanitize(REQUESTS[-1]["body"])
        row["headers"] = REQUESTS[-1]["headers"]
    return row


def read_pty(fd, seconds):
    chunks = []
    end = time.monotonic() + seconds
    while time.monotonic() < end:
        ready, _, _ = select.select([fd], [], [], min(0.1, max(0, end-time.monotonic())))
        if ready:
            try:
                data = os.read(fd, 65536)
            except OSError:
                break
            if not data:
                break
            chunks.append(data)
    return b"".join(chunks).decode("utf-8", "replace")


def chat(name, extra=None, inputs=("/help", "hi", "/exit"), want_request=True, ax=True, provider=None):
    master, slave = pty.openpty()
    fcntl.ioctl(slave, termios.TIOCSWINSZ, struct.pack("HHHH", 30, 100, 0, 0))
    args = ["chat", "--ax-screen-reader" if ax else "--no-ax-screen-reader",
            "--model-provider", provider or BASE, "-m", "cap-model", *(extra or [])]
    before = len(REQUESTS)
    proc = subprocess.Popen(["/usr/bin/fm", *args], stdin=slave, stdout=slave, stderr=slave,
                            env=ENV, cwd=WORK, start_new_session=True,
                            preexec_fn=lambda: fcntl.ioctl(0, termios.TIOCSCTTY, 0))
    os.close(slave)
    out = read_pty(master, 0.4)
    for line in inputs:
        if proc.poll() is not None:
            break
        try:
            os.write(master, (line + ("\n" if ax else "\r")).encode())
        except OSError:
            break
        out += read_pty(master, 0.7)
    (WORK / (name + ".log")).write_text(out)
    naturally_exited = proc.poll() is not None
    if not naturally_exited:
        try:
            os.write(master, b"\x04")
            out += read_pty(master, 0.2)
            os.write(master, b"\x03")
            out += read_pty(master, 0.2)
        except OSError:
            pass
        try:
            proc.terminate()
        except (PermissionError, ProcessLookupError):
            pass
    try:
        proc.wait(timeout=2)
    except subprocess.TimeoutExpired:
        try:
            proc.kill()
        except (PermissionError, ProcessLookupError):
            pass
    out += read_pty(master, 0.1)
    os.close(master)
    status = "PASS" if proc.returncode == 0 and (
        (len(REQUESTS) > before and "pong" in out) if want_request else naturally_exited) else "FAIL"
    row = record(name, status, args, out, natural_exit=naturally_exited,
                 request_count=len(REQUESTS)-before, returncode=proc.returncode, inputs=list(inputs))
    if len(REQUESTS) > before:
        row["request"] = sanitize(REQUESTS[-1]["body"])
    return row


def http(base, path, payload=None):
    data = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(base + path, data=data,
                                    headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(request, timeout=3) as response:
        return response.status, response.read().decode()


def serve_check(socket_mode=False):
    name = "serve.unix" if socket_mode else "serve.tcp"
    if socket_mode:
        sock = WORK / "fm.sock"
        args = ["serve", "--socket", str(sock), "--model-provider", BASE,
                "--model-provider-header", "X-Fm-Verify: serve"]
        base = None
    else:
        with socket.socket() as probe:
            probe.bind(("127.0.0.1", 0))
            port = probe.getsockname()[1]
        args = ["serve", "--host", "127.0.0.1", "--port", str(port), "--model-provider", BASE,
                "--model-provider-header", "X-Fm-Verify: serve"]
        base = f"http://127.0.0.1:{port}"
    log = (WORK / (name + ".log")).open("w")
    proc = subprocess.Popen(["/usr/bin/fm", *args], env=ENV, stdout=log, stderr=log,
                            cwd=WORK, start_new_session=True)
    evidence = []
    try:
        for attempt in range(20):
            try:
                if socket_mode:
                    result = subprocess.run(["curl", "--silent", "--show-error", "--max-time", "2",
                                             "--unix-socket", str(sock), "http://localhost/health"],
                                            capture_output=True, text=True)
                    require(result.returncode == 0, "unix socket not ready")
                else:
                    http(base, "/health")
                break
            except Exception:
                if proc.poll() is not None:
                    raise RuntimeError("serve exited before ready")
                time.sleep(0.1)
        for path, payload in [
            ("/health", None), ("/v1/models", None),
            ("/v1/chat/completions", {"model": "cap-model", "stream": False,
                                     "messages": [{"role": "user", "content": "hi"}]}),
            ("/v1/chat/completions", {"model": "cap-model", "stream": True,
                                     "messages": [{"role": "user", "content": "hi"}]})
        ]:
            if socket_mode:
                cmd = ["curl", "--silent", "--show-error", "--max-time", "3", "--unix-socket",
                       str(sock), "http://localhost" + path]
                if payload is not None:
                    cmd += ["-H", "Content-Type: application/json", "-d", json.dumps(payload)]
                result = subprocess.run(cmd, capture_output=True, text=True)
                require(result.returncode == 0, result.stderr)
                text = result.stdout
            else:
                code, text = http(base, path, payload)
                require(code == 200, f"HTTP {code}")
            if path.endswith("models"):
                require("cap-model" in text, "custom model not listed")
            elif payload is not None:
                require("pong" in text, "serve proxy response missing")
                if payload["stream"]:
                    require("[DONE]" in text, "missing stream DONE")
            evidence.append({"path": path, "stream": (payload or {}).get("stream"), "response": text})
        record(name, "PASS", args, evidence=json.dumps(evidence))
    except Exception as exc:
        record(name, "FAIL", args, stderr=str(exc), evidence=json.dumps(evidence))
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.wait()
        log.close()


def main():
    global ENV
    for command in ["chat", "config", "count-tokens", "license", "models",
                    "quota-usage", "respond", "schema", "serve"]:
        invoke("help." + command, [command, "--help"])
    invoke("help.schema.object", ["schema", "object", "--help"])
    invoke("config.path", ["config", "path"],
           check=lambda out, err: require(str(HOME) in out, "configuration not isolated"))
    invoke("config.add", ["config", "add", "model-provider", "verify", BASE])
    invoke("config.set.provider", ["config", "set", "default-model-provider", "verify"])
    invoke("config.set.model", ["config", "set", "default-model", "cap-model"])
    invoke("config.get.model", ["config", "get", "default-model"],
           check=lambda out, err: require("cap-model" in out, "model not persisted"))
    invoke("config.get.provider", ["config", "get", "default-model-provider"],
           check=lambda out, err: require("verify" in out, "provider not persisted"))
    invoke("config.list", ["config", "list"], check=lambda out, err: require(BASE in out, "provider missing"))
    invoke("config.replace", ["config", "add", "model-provider", "temporary", BASE])
    invoke("config.replace.again", ["config", "add", "model-provider", "temporary", BASE + "/updated"])
    invoke("config.remove", ["config", "remove", "model-provider", "temporary"])
    invoke("config.remove.verify_absent", ["config", "list"],
           check=lambda out, err: require("temporary" not in out, "provider was not removed"))
    invoke("config.invalid.key", ["config", "set", "unknown-option", "x"], reject=True)
    invoke("models.named", ["models", "--model-provider", "verify"],
           check=lambda out, err: require("cap-model" in out, "model absent"))
    invoke("models.url", ["models", "--model-provider", BASE],
           check=lambda out, err: require("cap-model" in out, "model absent"))
    invoke("models.default", ["models"], blocked=True,
           check=lambda out, err: require("cap-model" in out, "model absent"))
    schema_args = ["schema", "object", "--name", "Sample", "--string", "name", "--integer", "age",
                   "--double", "ratio", "--boolean", "enabled", "--string", "tags", "--array",
                   "--string", "note", "--optional", "--description", "Optional note"]
    def validate_schema(out, err):
        schema = json.loads(out)
        p = schema["properties"]
        require([p[k]["type"] for k in ["name", "age", "ratio", "enabled", "tags"]] ==
                ["string", "integer", "number", "boolean", "array"], "wrong property types")
        require("note" not in schema["required"] and p["note"]["description"] == "Optional note",
                "optional/description lost")
        require(schema["additionalProperties"] is False, "strict object missing")
    generated = invoke("schema.types_modifiers", schema_args, check=validate_schema)
    schema_path = WORK / "sample.json"
    schema_path.write_text(generated["stdout"])
    nested_schema = '{"type":"object","title":"Address","properties":{"zip":{"type":"string"}},"required":["zip"],"additionalProperties":false}'
    for flag in ["--object", "--nested"]:
        invoke("schema.nested." + flag, ["schema", "object", "--name", "Person", flag, "address", "--schema", nested_schema],
               check=lambda out, err: require(json.loads(out)["$defs"]["Address"]["type"] == "object"
                                               and "$ref" in json.loads(out)["properties"]["address"], "nested missing"))
    invoke("schema.dot_notation", ["schema", "object", "--name", "Person", "--string", "address.street", "--integer", "address.number"],
           check=lambda out, err: require("street" in json.loads(out)["$defs"]["Address"]["properties"], "dot nesting failed"))
    invoke("schema.integer_alias", ["schema", "object", "--name", "Person", "--int", "age"],
           check=lambda out, err: require(json.loads(out)["properties"]["age"]["type"] == "integer", "int alias failed"))
    invoke("schema.anyOf", ["schema", "object", "--name", "Union", "--anyOf", "--schema", nested_schema, "--schema", nested_schema.replace("Address", "Other")],
           check=lambda out, err: require(len(json.loads(out)["anyOf"]) == 2, "union choices missing"))
    invoke("schema.missing.name", ["schema", "object", "--string", "name"], reject=True)
    invoke("schema.bad.nested", ["schema", "object", "--name", "Bad", "--object", "address", "--schema", "not-json"], reject=True)
    invoke("license.status", ["license", "--status"])
    invoke("license.show", ["license", "--show"],
           check=lambda out, err: require("LEGAL NOTICE & TERMS" in out and "apple.com/legal/sla" in out, "legal text missing"))
    record("license.agreement", "NOT_RUN", ["license"], reason="No legal assent is made on the user's behalf.")
    respond("respond.stream")
    respond("respond.buffered", ["--no-stream"],
            check_request=lambda r: require(r["body"]["stream"] is True, "no-stream should be client buffering"))
    respond("respond.instructions", ["-i", "be concise"],
            check_request=lambda r: require(any(m.get("content") == "be concise" for m in r["body"]["messages"]), "instructions absent"))
    respond("respond.stdin", prompt=None, stdin="stdin prompt",
            check_request=lambda r: require("stdin prompt" in json.dumps(r["body"]), "stdin lost"))
    respond("respond.text", ["--text", "alpha", "--text", "beta"], prompt=None,
            check_request=lambda r: require("alpha" in json.dumps(r["body"]) and "beta" in json.dumps(r["body"]), "text lost"))
    respond("respond.headers", ["--model-provider-header", "X-Fm-Verify: one", "--model-provider-header", "X-Extra: two"],
            check_request=lambda r: require(r["headers"].get("X-Fm-Verify") == "one" and r["headers"].get("X-Extra") == "two", "headers lost"))
    respond("respond.verbose", ["--verbose"])
    respond("respond.schema", ["--schema", str(schema_path)], prompt="sample", expected='"name"',
            check_request=lambda r: require(r["body"]["response_format"]["type"] == "json_schema", "schema lost"))
    respond("respond.image", ["--image", str(WORK / "ocr.png"), "--text", "describe"], prompt=None,
            check_request=lambda r: require("data:image/jpeg;base64," in json.dumps(r["body"]), "image not encoded"))
    respond("respond.image_labels", ["--tool", "ocr", "--image", str(WORK / "ocr.png"), "--label", "text",
                                    "--image", str(WORK / "qr.png"), "--label", "barcode"], prompt="describe",
            check_request=lambda r: require(json.dumps(r["body"]).count("data:image/jpeg;base64,") == 2, "multiple images lost"))
    for tool, image, text in [("ocr", "ocr.png", "FM VERIFY 12345"), ("barcode", "qr.png", "FM-VERIFY-QR-12345")]:
        respond("respond.tool." + tool, ["--tool", tool, "--image", str(WORK / image)], prompt="extract text",
                check_request=lambda r, expected=text: require(expected in json.dumps(r["body"]), "recognized tool result not forwarded"))
    respond("respond.tools.repeat", ["--tool", "ocr", "--tool", "barcode"], prompt="hi")
    transcript = WORK / "transcript.json"
    respond("respond.save_transcript", ["--save-transcript", str(transcript)],
            check_request=lambda r: require(transcript.exists() and len(transcript.read_bytes()) > 50, "transcript missing"))
    respond("respond.resume", ["--resume", str(transcript)], prompt="next",
            check_request=lambda r: require("pong" in json.dumps(r["body"]) and "next" in json.dumps(r["body"]), "conversation history lost"))
    greedy = invoke("respond.greedy.custom", ["respond", "--model-provider", BASE, "-m", "cap-model", "-g", "hi"], reject=True)
    if "Greedy sampling is not supported" in greedy["stdout"] + greedy["stderr"]:
        greedy["status"] = "UNSUPPORTED"
        greedy["reason"] = "Custom provider explicitly rejects greedy sampling."
    invoke("respond.bad.image", ["respond", "--model-provider", BASE, "-m", "cap-model", "--image", str(WORK / "missing.png"), "hi"], reject=True)
    invoke("respond.label_without_tool", ["respond", "--model-provider", BASE, "-m", "cap-model",
                                          "--image", str(WORK / "ocr.png"), "--label", "text", "hi"], reject=True)
    invoke("respond.bad.schema", ["respond", "--model-provider", BASE, "-m", "cap-model", "--schema", str(WORK / "missing.json"), "hi"], reject=True)
    invoke("respond.bad.tool", ["respond", "--model-provider", BASE, "-m", "cap-model", "--tool", "unknown-tool", "hi"], reject=True)
    invoke("respond.bad.option", ["respond", "--does-not-exist", "hi"], reject=True)
    invoke("respond.provider_error", ["respond", "--model-provider", BASE, "-m", "error-model", "hi"], reject=True)
    invoke("respond.no.prompt", ["respond", "--model-provider", BASE, "-m", "cap-model"], reject=True)
    custom_env = ENV
    system_home = WORK / "system-home"
    system_home.mkdir(exist_ok=True)
    ENV = dict(ENV, HOME=str(system_home), CFFIXED_USER_HOME=str(system_home))
    invoke("models.builtin", ["models"], blocked=True)
    invoke("respond.system", ["respond", "-m", "system", "Reply OK"], timeout=8, blocked=True)
    invoke("respond.system.use_case", ["respond", "-m", "system", "--use-case", "content-tagging", "hello"], timeout=8, blocked=True)
    invoke("respond.system.guardrails", ["respond", "-m", "system", "--guardrails", "permissive-content-transformations", "hello"], timeout=8, blocked=True)
    invoke("respond.system.greedy", ["respond", "-m", "system", "-g", "hello"], timeout=8, blocked=True)
    record("respond.pcc.generation", "NOT_RUN", ["respond", "-m", "pcc"], reason="Cloud inference is not triggered; availability is probed using quota only.")
    for name, args, stdin in [
        ("count_tokens.prompt", ["count-tokens", "Hello world"], None),
        ("count_tokens.quiet", ["count-tokens", "--quiet", "Hello world"], None),
        ("count_tokens.instructions", ["count-tokens", "-i", "Be concise", "Hello"], None),
        ("count_tokens.instructions_only", ["count-tokens", "-i", "Be concise"], None),
        ("count_tokens.stdin", ["count-tokens"], "Hello world"),
        ("count_tokens.image_text", ["count-tokens", "--image", str(WORK / "ocr.png"), "--text", "Describe"], None),
        ("count_tokens.transcript", ["count-tokens", "--transcript", str(transcript)], None)
    ]:
        invoke(name, args, stdin=stdin, blocked=True)
    for model in [None, "system", "pcc"]:
        invoke("quota." + str(model or "all"), ["quota-usage", *([] if model is None else ["-m", model])], blocked=True)
    invoke("quota.invalid.model", ["quota-usage", "-m", "bad-model"], reject=True)
    ENV = custom_env
    first_chat = chat("chat.interactive")
    sessions = sorted((HOME / ".fm/sessions").glob("*")) if (HOME / ".fm/sessions").exists() else []
    first_chat["session_files"] = [p.name for p in sessions]
    chat("chat.continue", ["--continue"], inputs=("next", "/exit"))
    if sessions:
        chat("chat.resume", ["--resume", sessions[0].stem], inputs=("next", "/exit"))
    else:
        record("chat.resume", "BLOCKED", ["chat", "--resume"], reason="No saved session was created.")
    chat("chat.instructions_tools", ["-i", "be concise", "--tool", "ocr", "--tool", "barcode"], inputs=("hi", "/exit"))
    invoke("chat.persist_preferences", ["chat", "--set-ax-screen-reader", "--set-ax-bell", "false", "--set-default-model", "system"])
    invoke("chat.persist_no_ax", ["chat", "--set-no-ax-screen-reader", "--set-ax-bell", "true", "--set-default-model", "pcc"])
    chat("chat.no_ax_renderer", inputs=("hi", "/quit"), ax=False)
    chat("chat.runtime_commands", inputs=(
        "/instructions Be concise", "/tools", "/tools add ocr", "/tools add barcode",
        "/tools remove ocr", "/model cap-model", "hi", "/save verify-session",
        "/sessions", "/tokens", "/clear", "fresh", "/resume verify-session", "next", "/quit"))
    chat("chat.provider_headers", ["--model-provider-header", "X-Fm-Verify: chat"], inputs=("hi", "/quit"))
    serve_check()
    serve_check(socket_mode=True)
    invoke("serve.invalid.port", ["serve", "--port", "70000"], reject=True)
    invoke("serve.conflicting.transport", ["serve", "--socket", str(WORK / "conflict.sock"), "--port", "19888"], reject=True)
    record("config.user_unchanged", "PASS" if hashlib.sha256(USER_CONFIG.read_bytes()).hexdigest() == ORIGINAL_HASH else "FAIL",
           ["sha256", "~/.fm/config.json"], reason="Compared before/after; no user configuration data is exported.")
    server.shutdown()
    (WORK / "results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print(json.dumps({status: sum(r["status"] == status for r in RESULTS)
                      for status in sorted({r["status"] for r in RESULTS})}), flush=True)


if __name__ == "__main__":
    main()
