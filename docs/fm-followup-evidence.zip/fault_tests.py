import concurrent.futures
import http.client
import json
import os
from pathlib import Path
import pty
import select
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WORK = Path(__file__).parent
HOME = WORK / "fault-home"
HOME.mkdir(exist_ok=True)
ENV = dict(os.environ, HOME=str(HOME), CFFIXED_USER_HOME=str(HOME))
RESULTS = []
REQUESTS = []
COUNTERS = {"active": 0, "peak": 0, "cancelled": 0}
LOCK = threading.Lock()
MODES = ["normal", "fragmented", "crlf", "large", "missing_usage", "missing_finish",
         "eof", "error_before", "error_after", "malformed_before", "malformed_after",
         "event_error_before", "event_error_after",
         "multiline", "stall", "hold", "http401", "http429", "http503"]
TEXT = "alpha"
UNICODE = "中文🙂\n第二行"
LARGE = "z" * 70000 + "🙂"


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def record(name, ok, **details):
    row = {"name": name, "status": "PASS" if ok else "FAIL", **details}
    RESULTS.append(row)
    (WORK / "fault-results.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print(f"{row['status']:5} {name}: {details.get('reason', '')}", flush=True)
    return row


def frame(content=None, finish=None, usage=False):
    chunk = {"id": "chatcmpl-followup", "object": "chat.completion.chunk",
             "created": 1700000000, "model": "test", "choices": [] if usage else [{
                 "index": 0, "delta": {} if content is None else {
                     "role": "assistant", "content": content}, "finish_reason": finish}]}
    if usage:
        chunk["usage"] = {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4}
    return ("data: " + json.dumps(chunk, ensure_ascii=False) + "\n\n").encode()


ERROR = b'data: {"error":{"message":"injected upstream failure","type":"server_error","code":"injected_error"}}\n\n'


class FaultProvider(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def do_GET(self):
        body = json.dumps({"object": "list", "data": [
            {"id": mode, "object": "model", "owned_by": "followup"} for mode in MODES]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def wait_for_disconnect(self, limit=3):
        start = time.monotonic()
        while time.monotonic()-start < limit:
            readable, _, _ = select.select([self.connection], [], [], 0.05)
            try:
                if readable and not self.connection.recv(1, socket.MSG_PEEK):
                    with LOCK:
                        COUNTERS["cancelled"] += 1
                    return
            except OSError:
                return

    def do_POST(self):
        request = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))))
        mode = request.get("model", "normal")
        with LOCK:
            REQUESTS.append(request)
            COUNTERS["active"] += 1
            COUNTERS["peak"] = max(COUNTERS["peak"], COUNTERS["active"])
        try:
            if mode.startswith("http"):
                code = int(mode[4:])
                body = json.dumps({"error": {"message": "injected HTTP error",
                                            "type": "server_error", "code": str(code)}}).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            if mode == "hold":
                threading.Event().wait(0.2)
            if not request.get("stream"):
                body = json.dumps({"id": "test", "object": "chat.completion", "created": 1700000000,
                    "model": mode, "choices": [{"index": 0, "message": {
                        "role": "assistant", "content": TEXT}, "finish_reason": "stop"}],
                    "usage": {"prompt_tokens": 3, "completion_tokens": 1, "total_tokens": 4}}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Connection", "close")
            self.end_headers()
            self.close_connection = True
            if mode == "stall":
                self.wfile.write(frame(TEXT))
                self.wfile.flush()
                self.wait_for_disconnect()
                return
            if mode in ("error_before", "error_after"):
                body = (frame(TEXT) if mode.endswith("after") else b"") + ERROR
            elif mode in ("event_error_before", "event_error_after"):
                body = (frame(TEXT) if mode.endswith("after") else b"") + b"event: error\n" + ERROR
            elif mode in ("malformed_before", "malformed_after"):
                body = (frame(TEXT) if mode.endswith("after") else b"") + b"data: {not-json}\n\n"
            elif mode == "multiline":
                chunk = frame(TEXT)
                body = chunk.replace(b', "object"', b',\ndata: "object"', 1)
                body += frame(finish="stop") + frame(usage=True) + b"data: [DONE]\n\n"
            else:
                text = UNICODE if mode in ("fragmented", "crlf") else LARGE if mode == "large" else TEXT
                body = b": keepalive\n\n" + frame(text)
                if mode != "missing_finish" and mode != "eof":
                    body += frame(finish="stop")
                if mode != "missing_usage" and mode != "eof":
                    body += frame(usage=True)
                if mode != "eof":
                    body += b"data: [DONE]\n\n"
            if mode == "crlf":
                body = body.replace(b"\n", b"\r\n")
            step = 3 if mode == "fragmented" else 8192
            for offset in range(0, len(body), step):
                self.wfile.write(body[offset:offset+step])
                self.wfile.flush()
        except (OSError, ValueError):
            pass
        finally:
            with LOCK:
                COUNTERS["active"] -= 1


provider = ThreadingHTTPServer(("127.0.0.1", 0), FaultProvider)
threading.Thread(target=provider.serve_forever, daemon=True).start()
BACKEND = f"http://127.0.0.1:{provider.server_port}/v1"
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    PORT = sock.getsockname()[1]
GATEWAY = f"http://127.0.0.1:{PORT}/v1"
config = {"listen": f"127.0.0.1:{PORT}", "backends": [
    {"name": "fault", "type": "openai", "url": BACKEND, "max_concurrency": 2,
     "queue_depth": 2, "queue_timeout": "500ms"},
    {"name": "healthy", "type": "openai", "url": BACKEND, "max_concurrency": 2,
     "queue_depth": 2, "queue_timeout": "500ms"}],
    "aliases": {mode: {"backend": "fault", "model": mode} for mode in MODES},
    "timeouts": {"stream_idle": "350ms", "stream_max": "1200ms", "non_stream": "2s", "drain": "1s"}}
config["aliases"].update({
    "backup": {"backend": "healthy", "model": "normal"},
    "auto_http": {"backend": "fault", "model": "http503", "fallback": ["backup"]},
    "auto_sse": {"backend": "fault", "model": "error_before", "fallback": ["backup"]},
})
config_path = WORK / "fault-config.json"
config_path.write_text(json.dumps(config))
log = (WORK / "gateway.log").open("w")
gateway = subprocess.Popen([str(WORK / "fmux-check"), "serve", "--config", str(config_path),
                            "--listen", f"127.0.0.1:{PORT}", "--log-level", "debug"],
                           stdout=log, stderr=log)


def gateway_http(mode, stream=True):
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=3)
    conn.request("POST", "/v1/chat/completions", body=json.dumps({
        "model": mode, "stream": stream, "stream_options": {"include_usage": True},
        "messages": [{"role": "user", "content": "test"}]}),
        headers={"Content-Type": "application/json"})
    response = conn.getresponse()
    body = response.read().decode()
    status = response.status
    conn.close()
    return status, body


def fm(name, base, mode, expected=None, expect_error=False, extra=(), prompt="test"):
    args = ["respond", "--model-provider", base, "-m", mode, *extra, prompt]
    start = time.monotonic()
    process = subprocess.Popen(["/usr/bin/fm", *args], stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, env=ENV)
    timed_out = False
    try:
        out, err = process.communicate(timeout=4)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.terminate()
        try:
            out, err = process.communicate(timeout=1)
        except subprocess.TimeoutExpired:
            process.kill()
            out, err = process.communicate()
    ok = not timed_out and (process.returncode != 0 if expect_error else process.returncode == 0)
    if expected is not None and not expect_error:
        ok = ok and out.strip() == expected
    return record(name, ok, args=args, returncode=process.returncode, timed_out=timed_out,
                  duration_s=round(time.monotonic()-start, 4), output_chars=len(out),
                  stdout=out[:2000], stderr=err[:2000], reason="" if ok else "Unexpected completion/error semantics")


def chat_clear():
    before = len(REQUESTS)
    master, slave = pty.openpty()
    process = subprocess.Popen(["/usr/bin/fm", "chat", "--ax-screen-reader", "--model-provider", GATEWAY,
                                "-m", "normal"], stdin=slave, stdout=slave, stderr=slave, env=ENV)
    os.close(slave)
    output = bytearray()
    for line in ["first-turn", "/clear", "second-turn", "/quit"]:
        end = time.monotonic()+0.35
        while time.monotonic() < end:
            ready, _, _ = select.select([master], [], [], 0.05)
            if ready:
                try:
                    output.extend(os.read(master, 65536))
                except OSError:
                    break
        if process.poll() is not None:
            break
        try:
            os.write(master, (line+"\n").encode())
        except OSError:
            break
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        process.terminate()
        process.wait(timeout=2)
    while True:
        ready, _, _ = select.select([master], [], [], 0)
        if not ready:
            break
        try:
            data = os.read(master, 65536)
            if not data:
                break
            output.extend(data)
        except OSError:
            break
    os.close(master)
    requests = REQUESTS[before:]
    final = json.dumps(requests[-1]) if requests else ""
    record("chat.clear_removes_history", process.returncode == 0 and
           "second-turn" in final and "first-turn" not in final,
           returncode=process.returncode, stdout=output.decode("utf-8", "replace"),
           requests=requests)


def main():
    ready = False
    for attempt in range(30):
        try:
            conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=1)
            conn.request("GET", "/healthz")
            response = conn.getresponse()
            ready = response.status == 200
            response.read()
            conn.close()
            if ready:
                break
        except OSError:
            if gateway.poll() is not None:
                break
            threading.Event().wait(0.05)
    check(ready, "isolated gateway did not start; inspect gateway.log")
    for base_name, base in [("direct", BACKEND), ("gateway", GATEWAY)]:
        for mode, text in [("normal", TEXT), ("fragmented", UNICODE), ("crlf", UNICODE),
                           ("large", LARGE), ("missing_usage", TEXT), ("missing_finish", TEXT), ("eof", TEXT)]:
            fm(base_name+"."+mode, base, mode, expected=text)
        for mode in ["http401", "http429", "http503", "error_before", "error_after",
                     "event_error_before", "event_error_after", "malformed_before", "malformed_after"]:
            fm(base_name+"."+mode, base, mode, expect_error=True)
        fm(base_name+".multiline", base, "multiline", expected=TEXT)
    for mode in ["error_before", "error_after", "event_error_before", "event_error_after",
                 "malformed_before", "malformed_after", "stall", "eof", "missing_usage"]:
        status, body = gateway_http(mode)
        if "error" in mode or mode.startswith("malformed") or mode == "stall":
            ok = (status >= 400 or '"error"' in body) and "[DONE]" not in body
        else:
            ok = status == 200 and "[DONE]" in body
        record("wire."+mode, ok, http_status=status, body=body)
    fm("fallback.http503_recovers", GATEWAY, "auto_http", expected=TEXT)
    fm("fallback.sse_error_should_recover", GATEWAY, "auto_sse", expected=TEXT)
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=2)
    cancelled_before = COUNTERS["cancelled"]
    conn.request("POST", "/v1/chat/completions", body=json.dumps({
        "model": "stall", "stream": True, "messages": [{"role": "user", "content": "cancel"}]}),
        headers={"Content-Type": "application/json"})
    response = conn.getresponse()
    first_line = response.readline().decode()
    response.close()
    conn.close()
    deadline = time.monotonic()+1.5
    while time.monotonic() < deadline and COUNTERS["cancelled"] == cancelled_before:
        threading.Event().wait(0.02)
    record("cancel.propagates_to_backend", COUNTERS["cancelled"] > cancelled_before,
           first_line=first_line, cancelled_delta=COUNTERS["cancelled"]-cancelled_before)
    with LOCK:
        COUNTERS["peak"] = COUNTERS["active"]
    start = threading.Barrier(8)
    def worker(_):
        start.wait()
        return gateway_http("hold", stream=False)[0]
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
        statuses = list(pool.map(worker, range(8)))
    record("concurrency.bounded_gate", all(s in (200, 429) for s in statuses)
           and 200 in statuses and 429 in statuses and COUNTERS["peak"] <= 2,
           statuses=statuses, backend_peak=COUNTERS["peak"])
    one, two = WORK / "round-one.json", WORK / "round-two.json"
    fm("history.save_first", GATEWAY, "normal", expected=TEXT,
       extra=("--save-transcript", str(one)), prompt="first-turn")
    before = len(REQUESTS)
    fm("history.resume_second", GATEWAY, "normal", expected=TEXT,
       extra=("--resume", str(one), "--save-transcript", str(two)), prompt="second-turn")
    second = REQUESTS[-1] if len(REQUESTS) > before else {}
    serialized = json.dumps(second)
    record("history.resume_keeps_prior_turn", all(t in serialized for t in
           ("first-turn", "second-turn", "alpha")), request=second)
    before = len(REQUESTS)
    fm("history.resume_third", GATEWAY, "normal", expected=TEXT,
       extra=("--resume", str(two)), prompt="third-turn")
    third = REQUESTS[-1] if len(REQUESTS) > before else {}
    record("history.three_turns", all(t in json.dumps(third) for t in
           ("first-turn", "second-turn", "third-turn")), request=third)
    chat_clear()
    conn = http.client.HTTPConnection("127.0.0.1", PORT, timeout=2)
    conn.request("GET", "/metrics")
    response = conn.getresponse()
    metrics = response.read().decode()
    conn.close()
    record("resources.no_inflight_after_tests",
           'fmux_inflight_requests{backend="fault"} 0' in metrics, metrics=metrics)
    before = len(REQUESTS)
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
        request = pool.submit(gateway_http, "hold", False)
        deadline = time.monotonic()+1
        while len(REQUESTS) == before and time.monotonic() < deadline:
            threading.Event().wait(0.01)
        gateway.terminate()
        status, body = request.result(timeout=3)
    gateway.wait(timeout=3)
    record("shutdown.drains_active_request", status == 200 and gateway.returncode == 0,
           http_status=status, body=body, gateway_exit=gateway.returncode)
    print(json.dumps({"total": len(RESULTS), "passed": sum(r["status"] == "PASS" for r in RESULTS),
                      "failed": sum(r["status"] == "FAIL" for r in RESULTS)}), flush=True)


try:
    main()
finally:
    if gateway.poll() is None:
        gateway.terminate()
        try:
            gateway.wait(timeout=3)
        except subprocess.TimeoutExpired:
            gateway.kill()
            gateway.wait()
    log.close()
    provider.shutdown()
