# fm 补充验证证据包

包含本轮脚本、最终结果、日志和所测网关构建。
`fmux-check` 来自当前 workspace 的未提交源码，仅用于隔离回归，
不要用它替换正在运行的用户服务。

## 脚本

- `fault_tests.py`：55 项异常/资源/会话对照，用随机端口启动可控上游
  和隔离 fmux；使用同目录 `fmux-check`，不调用用户模型。
- `model_menu_probe.py`：2 项模型目录/聊天菜单对照，只列目录和选择模型，
  不提交生成提示。provider 返回不含特殊符号的 normal/backup。
- `check_metadata.py`：对 `fault-results.json` 的尾帧做 2 项离线校验。
  需要先有 fault suite 的结果。
- `trace_live.py`：真实本地模型追踪，会请求当前运行中的
  `127.0.0.1:1976` 网关及 Qwen 别名；110/45/45 秒为脚本观察上限，
  会占用推理资源，不是 mock。

本轮结果：故障套件 48/55 通过，目录/菜单 1/2 通过，元数据 0/2 通过。
这是多种断言，不是 59 项独立产品功能或 10 个独立缺陷。
CLI 对异常帧通常非零退出，但原始错误信息在网关中丢失；
不能以“CLI 退出失败”代替对 wire 协议和 fallback 的检查。

## 文件

最终数据分别为 `fault-results.json`、`menu-results.json`、
`metadata-results.json`、`live-trace.json`。
`go-race.txt` 是现有全量 Go race 回归的实际通过记录。
其他日志是诊断输出；正式结论以 workspace 的补充报告和合并 JSON 为准。
所有 HOME/config/session 临时内容在脚本所在目录，不写用户默认配置。
`check_report_links.py` 校验 workspace 中两份报告的交付物链接和源码行范围，
不启动模型或网关。
