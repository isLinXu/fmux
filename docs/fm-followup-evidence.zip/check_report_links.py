from pathlib import Path
import re
from urllib.parse import unquote, urlsplit

root = Path("/Users/linxu/projects/fmux/docs")
count = 0
for name in ["fm-functional-verification.md", "fm-followup-verification.md"]:
    document = root / name
    for raw in re.findall(r"\[[^\]]+\]\(([^)]+)\)", document.read_text()):
        uri = urlsplit(raw)
        if uri.scheme in ("http", "https", "mailto"):
            continue
        target = Path(unquote(uri.path)) if uri.scheme == "file" else root / unquote(uri.path)
        assert target.is_file(), f"{document.name}: missing {raw}"
        if uri.fragment.startswith("L"):
            bounds = [int(n) for n in re.findall(r"\d+", uri.fragment)]
            assert max(bounds) <= len(target.read_text().splitlines()), f"invalid line range: {raw}"
        count += 1
print(f"Supplemental report links: {count} checked, all valid")
