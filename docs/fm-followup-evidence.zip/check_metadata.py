import json
from pathlib import Path

work = Path(__file__).parent
cases = json.loads((work / "fault-results.json").read_text())
results = []
for name in ["wire.eof", "wire.missing_usage"]:
    case = next(row for row in cases if row["name"] == name)
    chunks = []
    for line in case["body"].splitlines():
        if line.startswith("data:") and line[5:].strip() != "[DONE]":
            chunks.append(json.loads(line[5:].strip()))
    fields = {field: [chunk.get(field) for chunk in chunks] for field in ["id", "created", "model"]}
    ok = bool(chunks) and all(len(set(values)) == 1 for values in fields.values())
    results.append({"name": "metadata." + name.removeprefix("wire."),
                    "status": "PASS" if ok else "FAIL",
                    "source_case": name, "fields": fields})
(work / "metadata-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, indent=2, ensure_ascii=False))
