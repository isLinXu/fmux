import http.client
import json
import os
from pathlib import Path
import pty
import re
import select
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WORK = Path(__file__).parent
HOME = WORK / "home"
HOME.mkdir(exist_ok=True)
ENV = dict(os.environ, HOME=str(HOME), CFFIXED_USER_HOME=str(HOME))
TRACES = {}
RESULTS = []


class TraceProxy(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *args):
        pass

    def do_GET(self):
        conn = http.client.HTTPConnection("127.0.0.1", 1976, timeout=5)
        try:
            conn.request("GET", self.path)
            response = conn.getresponse()
            body = response.read()
            self.send_response(response.status)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        finally:
            conn.close()

    def do_POST(self):
        name = self.headers.get("X-Followup-Case", "unknown")
        start = time.monotonic()
        trace = {"name": name, "events": [], "content": "", "done": False,
                 "finish_reasons": [], "usage": None, "cancelled": False}
        TRACES[name] = trace
        body = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        trace["request"] = json.loads(body)
        conn = http.client.HTTPConnection("127.0.0.1", 1976, timeout=125)
        finished = threading.Event()
        trace["_finished"] = finished

        def detect_disconnect():
            while not finished.wait(0.1):
                try:
                    readable, _, _ = select.select([self.connection], [], [], 0)
                    if readable and not self.connection.recv(1, socket.MSG_PEEK):
                        trace["cancelled"] = True
                        if conn.sock:
                            conn.sock.shutdown(socket.SHUT_RDWR)
                        conn.close()
                        return
                except OSError:
                    return

        threading.Thread(target=detect_disconnect, daemon=True).start()
        try:
            conn.request("POST", self.path, body=body, headers={
                "Content-Type": "application/json",
                "User-Agent": self.headers.get("User-Agent", "fm-followup"),
                "X-Request-Id": "followup-" + name,
            })
            response = conn.getresponse()
            trace["status"] = response.status
            trace["headers_s"] = round(time.monotonic()-start, 4)
            self.send_response(response.status)
            self.send_header("Content-Type", response.getheader("Content-Type", "text/event-stream"))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.flush()
            self.close_connection = True
            while True:
                line = response.readline()
                if not line:
                    break
                if line.startswith(b"data:"):
                    payload = line[5:].strip()
                    elapsed = round(time.monotonic()-start, 4)
                    event = {"time_s": elapsed}
                    if payload == b"[DONE]":
                        trace["done"] = True
                        event["done"] = True
                    else:
                        try:
                            chunk = json.loads(payload)
                            for choice in chunk.get("choices") or []:
                                delta = choice.get("delta") or {}
                                content = delta.get("content") or ""
                                if content:
                                    trace.setdefault("first_content_s", elapsed)
                                    trace["content"] += content
                                    event["content_chars"] = len(content)
                                if choice.get("finish_reason"):
                                    trace["finish_reasons"].append(choice["finish_reason"])
                                    event["finish_reason"] = choice["finish_reason"]
                            if chunk.get("usage") is not None:
                                trace["usage"] = chunk["usage"]
                                event["usage"] = True
                            if "error" in chunk:
                                event["error"] = chunk["error"]
                        except (ValueError, TypeError) as error:
                            event["parse_error"] = str(error)
                    trace["events"].append(event)
                self.wfile.write(line)
                self.wfile.flush()
        except (OSError, http.client.HTTPException) as error:
            trace["transport_error"] = str(error)
        finally:
            trace["duration_s"] = round(time.monotonic()-start, 4)
            conn.close()
            finished.set()


proxy = ThreadingHTTPServer(("127.0.0.1", 0), TraceProxy)
threading.Thread(target=proxy.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{proxy.server_port}/v1"


def run(name, model, prompt, extra=(), timeout=45):
    args = ["respond", "--model-provider", BASE, "-m", model,
            "--model-provider-header", "X-Followup-Case: " + name, *extra, prompt]
    master, slave = pty.openpty()
    start = time.monotonic()
    process = subprocess.Popen(["/usr/bin/fm", *args], stdin=subprocess.DEVNULL,
                               stdout=slave, stderr=slave, env=ENV)
    os.close(slave)
    output = bytearray()
    first_output = None
    timed_out = False
    while process.poll() is None:
        if time.monotonic()-start > timeout:
            timed_out = True
            process.terminate()
            break
        readable, _, _ = select.select([master], [], [], 0.1)
        if readable:
            try:
                data = os.read(master, 65536)
            except OSError:
                break
            if not data:
                break
            if first_output is None:
                first_output = round(time.monotonic()-start, 4)
            output.extend(data)
    try:
        process.wait(timeout=2)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait()
    while True:
        readable, _, _ = select.select([master], [], [], 0)
        if not readable:
            break
        try:
            data = os.read(master, 65536)
        except OSError:
            break
        if not data:
            break
        output.extend(data)
    os.close(master)
    trace = TRACES.get(name, {})
    if trace.get("_finished"):
        trace["_finished"].wait(2)
    clean_trace = {k: v for k, v in trace.items() if k != "_finished"}
    text = output.decode("utf-8", "replace")
    plain = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text).replace("\r\n", "\n")
    row = {"name": name, "args": args, "timeout_s": timeout,
           "returncode": process.returncode, "timed_out": timed_out,
           "duration_s": round(time.monotonic()-start, 4),
           "first_terminal_output_s": first_output, "terminal_output": plain,
           "trace": clean_trace,
           "content_matches_terminal": plain.strip() == clean_trace.get("content", "").strip()}
    RESULTS.append(row)
    (WORK / "live-trace.json").write_text(json.dumps(RESULTS, indent=2, ensure_ascii=False))
    print(f"{name}: exit={process.returncode} timeout={timed_out} "
          f"first_content={trace.get('first_content_s')} done={trace.get('done')} "
          f"finish={trace.get('finish_reasons')} duration={row['duration_s']}s", flush=True)
    return row


baseline = run("swift_original_alias", "qwen3.8:27b", "What is Swift?", timeout=110)
run("swift_fast_alias", "qwen-fast", "What is Swift?", timeout=45)
run("swift_concise", "qwen-fast", "Explain Apple's Swift programming language in two sentences. /no_think",
    extra=("-i", "Be concise. Answer directly without reasoning."), timeout=45)
if not baseline["timed_out"] and baseline["duration_s"] < 45:
    run("swift_original_repeat", "qwen3.8:27b", "What is Swift?", timeout=45)
proxy.shutdown()
