import fcntl
import json
import os
from pathlib import Path
import pty
import select
import subprocess
import termios
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WORK = Path(__file__).parent
HOME = WORK / "menu-home"
HOME.mkdir(exist_ok=True)
ENV = dict(os.environ, HOME=str(HOME), CFFIXED_USER_HOME=str(HOME))
POSTS = []


class Catalog(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        body = json.dumps({"object": "list", "data": [
            {"id": name, "object": "model", "owned_by": "menu-test"} for name in ["normal", "backup"]]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        POSTS.append(json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0)))))
        self.send_response(500)
        self.end_headers()


server = ThreadingHTTPServer(("127.0.0.1", 0), Catalog)
threading.Thread(target=server.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{server.server_port}/v1"
discovery = subprocess.run(["/usr/bin/fm", "models", "--model-provider", BASE],
                           capture_output=True, text=True, env=ENV, timeout=3)


def read(fd, seconds):
    output = bytearray()
    end = time.monotonic()+seconds
    while time.monotonic() < end:
        ready, _, _ = select.select([fd], [], [], 0.05)
        if ready:
            try:
                data = os.read(fd, 65536)
            except OSError:
                break
            if not data:
                break
            output.extend(data)
    return bytes(output)


master, slave = pty.openpty()
chat = subprocess.Popen(["/usr/bin/fm", "chat", "--ax-screen-reader",
                         "--model-provider", BASE, "-m", "normal"],
                        stdin=slave, stdout=slave, stderr=slave, env=ENV,
                        start_new_session=True,
                        preexec_fn=lambda: fcntl.ioctl(0, termios.TIOCSCTTY, 0))
os.close(slave)
output = read(master, 0.4)
for command in ["/model backup", "/model normal", "/quit"]:
    if chat.poll() is not None:
        break
    try:
        os.write(master, (command+"\n").encode())
    except OSError:
        break
    output += read(master, 0.4)
try:
    chat.wait(timeout=2)
except subprocess.TimeoutExpired:
    chat.terminate()
    chat.wait(timeout=2)
output += read(master, 0.1)
os.close(master)
text = output.decode("utf-8", "replace")
results = [
    {"name": "menu.catalog_lists_plain_ids",
     "status": "PASS" if discovery.returncode == 0 and all(s in discovery.stdout for s in ["normal", "backup"]) else "FAIL",
     "stdout": discovery.stdout, "stderr": discovery.stderr, "returncode": discovery.returncode},
    {"name": "menu.runtime_switch_plain_id",
     "status": "FAIL" if "Unknown model 'backup'" in text else "PASS" if chat.returncode == 0 else "FAIL",
     "stdout": text, "returncode": chat.returncode, "posts": POSTS,
     "commands": ["/model backup", "/model normal", "/quit"]},
]
server.shutdown()
(WORK / "menu-results.json").write_text(json.dumps(results, indent=2, ensure_ascii=False))
print(json.dumps(results, ensure_ascii=False, indent=2))
