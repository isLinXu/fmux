import hashlib
import json
import re
import statistics
import subprocess
from pathlib import Path
import zipfile

WORK = Path(__file__).parent
PROJECT = Path("/Users/linxu/projects/fmux")
faults = json.loads((WORK / "fault-results.json").read_text())
metadata = json.loads((WORK / "metadata-results.json").read_text())
failures = [r["name"] for r in faults if r["status"] == "FAIL"]
assert len(faults) == 55 and failures == ["direct.multiline"], failures
assert len(metadata) == 2 and all(r["status"] == "PASS" for r in metadata)
resources = next(r for r in faults if r["name"] == "resources.no_inflight_after_tests")
samples = [line.rsplit(" ", 1)[0] for line in resources["metrics"].splitlines()
           if line and not line.startswith("#")]
assert len(samples) == len(set(samples)), "duplicate metrics samples"
metrics_wire = {"name": "wire.metrics_samples_unique", "status": "PASS",
                "sample_count": len(samples)}
old = json.loads((Path("/tmp/fmux-fm-followup.x2VlJX") / "fault-results.json").read_text())
old_status = {r["name"]: r["status"] for r in old}
resolved = [r["name"] for r in faults
            if old_status.get(r["name"]) == "FAIL" and r["status"] == "PASS"]


def benchmarks(name):
    text = (WORK / name).read_text()
    rows = {}
    for line in text.splitlines():
        match = re.match(r"BenchmarkExport/(\w+)-\d+\s+\d+\s+(\d+) ns/op\s+(\d+) B/op\s+(\d+) allocs/op", line)
        if match:
            case = match[1]
            rows.setdefault(case, []).append({
                "ns_op": int(match[2]), "bytes_op": int(match[3]), "allocs_op": int(match[4])
            })
    assert set(rows) == {"Render", "RecordAndScrape"}
    return {case: {"runs": runs, "median": {
        field: statistics.median(run[field] for run in runs)
        for field in ["ns_op", "bytes_op", "allocs_op"]}}
        for case, runs in rows.items()}


result = {
    "date": "2026-11-04",
    "scope": "SSE protocol correctness and approved metrics export repair; isolated build only",
    "assertions": faults + metadata + [metrics_wire],
    "summary": {"total": 58, "passed": 57, "failed": 1,
                "remaining_failure": "fm direct.multiline; gateway.multiline passes"},
    "previous_fault_failures_resolved": resolved,
    "benchmarks": {
        "before": benchmarks("metrics-before.txt"),
        "after_isolated": benchmarks("metrics-after-isolated.txt"),
        "command": "go test ./internal/metrics -run '^$' -bench BenchmarkExport -benchmem -count=3",
        "notes": [
            "3 runs, Apple M3 Max, GOMAXPROCS default 16.",
            "Initial after benchmark overlapped validation loads; retained in evidence but excluded from comparison.",
            "No statistical significance or inference throughput claim; label aggregation reduces output rows."
        ],
    },
    "go_race": {"command": "go test ./... -race -count=1", "exit_code": 0,
                "log": (WORK / "go-race.txt").read_text()},
    "go_version": subprocess.check_output(
        ["/Users/linxu/sdk/go/bin/go", "version"], text=True).strip(),
    "build_sha256": hashlib.sha256((WORK / "fmux-check").read_bytes()).hexdigest(),
    "notes": [
        "Original failure evidence is unchanged.",
        "fm model menu was not retested in this batch; remains an external CLI limitation.",
        "No real model performance run or deployed-service replacement.",
        "TTFT measurement boundary and budget eviction lifecycle are unchanged."
    ]
}
json_path = PROJECT / "docs/fmux-repair-results.json"
json_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")

archive_path = PROJECT / "docs/fmux-repair-evidence.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for name in [
        "fault_tests.py", "check_metadata.py", "summarize.py", "fault-results.json",
        "metadata-results.json", "fault-tests.log", "gateway.log", "fault-config.json",
        "metrics-before.txt", "metrics-after.txt", "metrics-after-isolated.txt",
        "go-race.txt", "fmux-check"
    ]:
        archive.write(WORK / name, name)
    for name in [
        "internal/adapter/openai/openai.go", "internal/adapter/openai/sse.go",
        "internal/adapter/openai/sse_test.go", "internal/api/chat.go",
        "internal/api/server.go", "internal/api/sse_correctness_test.go",
        "internal/metrics/metrics.go", "internal/metrics/export_test.go",
        "docs/superpowers/specs/2026-11-04-sse-correctness-design.md",
        "docs/superpowers/specs/2026-11-03-metrics-export-design.md",
        "docs/superpowers/plans/2026-11-04-sse-correctness.md",
        "docs/superpowers/plans/2026-11-04-metrics-export.md",
        "docs/fmux-repair-results.json", "docs/fmux-repair-verification.md"
    ]:
        archive.write(PROJECT / name, "source/" + name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
print(json.dumps({
    "summary": result["summary"], "resolved": resolved,
    "benchmarks": {key: {case: data["median"] for case, data in value.items()}
                   for key, value in result["benchmarks"].items()
                   if key in ["before", "after_isolated"]},
    "json": str(json_path), "zip": str(archive_path),
    "build_sha256": result["build_sha256"]
}, ensure_ascii=False, indent=2))
