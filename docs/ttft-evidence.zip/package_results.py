import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

WORK = Path(__file__).parent
PROJECT = Path("/Users/linxu/projects/fmux")
wire = json.loads((WORK / "wire-results.json").read_text())
assert wire["summary"] == {"total": 6, "passed": 6, "failed": 0}
red = (WORK / "ttft-red.txt").read_text()
assert "FAIL: TestTTFTIncludesPreparation" in red
green = (WORK / "ttft-green.txt").read_text()
assert green.startswith("ok")
race = (WORK / "go-race.txt").read_text()
targeted = (WORK / "targeted-race.txt").read_text()
assert "FAIL" not in race and "FAIL" not in targeted
sha = hashlib.sha256((WORK / "fmux-check").read_bytes()).hexdigest()
result = {
    "date": "2026-11-09",
    "scope": "Request-level TTFT start and first text/tool output endpoint; isolated build only",
    "wire": wire,
    "tdd": {"red_log": red, "green_log": green},
    "race": {"command": "go test ./... -race -count=1", "exit_code": 0, "log": race},
    "targeted_race": {"command": "go test ./internal/api ./internal/metrics -race -count=3",
                     "exit_code": 0, "log": targeted},
    "vet": {"command": "go vet ./...", "exit_code": 0},
    "build": {"command": "go build -trimpath -o fmux-check ./cmd/fmux",
              "exit_code": 0, "sha256": sha},
    "go_version": subprocess.check_output(
        ["/Users/linxu/sdk/go/bin/go", "version"], text=True).strip(),
    "notes": [
        "Metric name, backend label and millisecond buckets unchanged; historical scope not directly comparable.",
        "Includes routing, queueing, preparation and prior fallback targets after validation/normalization.",
        "Measures gateway output write, not network receipt or terminal display.",
        "First startup readiness attempt used a 1-second window and did not become ready; final script explicitly binds an isolated port and uses a 5-second health window.",
        "No real model performance claim, commit or running-service replacement.",
        "Budget accounting/lifecycle remains unchanged and needs a separately approved design."
    ]
}
path = PROJECT / "docs/ttft-results.json"
path.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
archive_path = PROJECT / "docs/ttft-evidence.zip"
with zipfile.ZipFile(archive_path, "w", zipfile.ZIP_DEFLATED) as archive:
    for name in ["verify_ttft.py", "package_results.py", "config.json", "wire-results.json",
                 "gateway.log", "ttft-red.txt", "ttft-green.txt", "targeted-race.txt",
                 "go-race.txt", "fmux-check"]:
        archive.write(WORK / name, name)
    for name in ["internal/api/chat.go", "internal/api/ttft_test.go",
                 "internal/metrics/metrics.go", "docs/architecture.md",
                 "docs/superpowers/specs/2026-11-09-ttft-design.md",
                 "docs/superpowers/plans/2026-11-09-ttft.md",
                 "docs/ttft-verification.md", "docs/ttft-results.json"]:
        archive.write(PROJECT / name, "source/" + name)
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
print(json.dumps({"summary": wire["summary"], "build_sha256": sha,
                  "json": str(path), "zip": str(archive_path)}))
