import http.client
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

WORK = Path(__file__).parent
RESULTS = []


def frame(delta=None, finish=None, usage=False):
    value = {"id": "ttft-test", "object": "chat.completion.chunk",
             "created": 1700000000, "model": "test", "choices": [] if usage else [{
                 "index": 0, "delta": delta or {}, "finish_reason": finish}]}
    if usage:
        value["usage"] = {"prompt_tokens": 1, "completion_tokens": 1, "total_tokens": 2}
    return ("data: " + json.dumps(value) + "\n\n").encode()


ERROR = b'data: {"error":{"message":"injected","type":"server_error","code":"injected_error"}}\n\n'


class Provider(BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_GET(self):
        body = b'{"object":"list","data":[{"id":"test","object":"model"}]}'
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self):
        value = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        mode = value["model"]
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.end_headers()
        try:
            if mode == "delayed_failure":
                threading.Event().wait(0.08)
                self.wfile.write(ERROR)
                return
            self.wfile.write(frame({"role": "assistant"}))
            self.wfile.write(frame(usage=True))
            self.wfile.flush()
            if mode in ["late_text", "late_tool"]:
                threading.Event().wait(0.08)
            if mode == "error_before":
                self.wfile.write(ERROR)
                return
            if mode != "controls_only":
                delta = ({"tool_calls": [{"index": 0, "id": "call", "type": "function",
                                         "function": {"name": "test_tool", "arguments": "{}"}}]}
                         if mode == "late_tool" else {"content": "alpha"})
                self.wfile.write(frame(delta))
            if mode == "error_after":
                self.wfile.write(ERROR)
                return
            self.wfile.write(frame(finish="stop") + b"data: [DONE]\n\n")
        except OSError:
            pass


provider = ThreadingHTTPServer(("127.0.0.1", 0), Provider)
thread = threading.Thread(target=provider.serve_forever, daemon=True)
thread.start()
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
base = f"http://127.0.0.1:{provider.server_port}/v1"
modes = ["late_text", "late_tool", "controls_only", "error_before", "error_after"]
config = {"listen": f"127.0.0.1:{port}",
          "backends": [{"name": name, "type": "openai", "url": base}
                       for name in ["source", "backup"]],
          "aliases": {mode: {"backend": "source", "model": mode} for mode in modes},
          "timeouts": {"stream_idle": "1s", "stream_max": "3s", "drain": "1s"}}
config["aliases"]["normal_backup"] = {"backend": "backup", "model": "normal"}
config["aliases"]["auto"] = {"backend": "source", "model": "delayed_failure",
                            "fallback": ["normal_backup"]}
(WORK / "config.json").write_text(json.dumps(config))
home = WORK / "home"
home.mkdir(exist_ok=True)
log = (WORK / "gateway.log").open("w")
gateway = subprocess.Popen([str(WORK / "fmux-check"), "serve", "--config",
                            str(WORK / "config.json"), "--listen", f"127.0.0.1:{port}",
                            "--log-level", "debug"],
                           stdout=log, stderr=log,
                           env=dict(os.environ, HOME=str(home), CFFIXED_USER_HOME=str(home)))


def request_http(path, body=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    conn.request("POST" if body is not None else "GET", path,
                 body=json.dumps(body) if body is not None else None,
                 headers={"Content-Type": "application/json"})
    response = conn.getresponse()
    status, data = response.status, response.read().decode()
    conn.close()
    return status, data


def metrics():
    status, text = request_http("/metrics")
    assert status == 200
    samples = {}
    for field, backend, raw in re.findall(
        r'fmux_time_to_first_token_milliseconds_(count|sum)\{backend="([^"]+)"\} (\d+)', text
    ):
        samples.setdefault(backend, {})[field] = int(raw)
    return samples, text


try:
    ready_deadline = time.monotonic() + 5
    while time.monotonic() < ready_deadline:
        try:
            if request_http("/healthz")[0] == 200:
                break
        except OSError:
            if gateway.poll() is not None:
                raise RuntimeError("gateway exited before ready")
            threading.Event().wait(0.01)
    else:
        raise RuntimeError("gateway did not become ready")
    for mode, backend, count, minimum in [
        ("late_text", "source", 1, 60),
        ("late_tool", "source", 1, 60),
        ("controls_only", "source", 0, 0),
        ("error_before", "source", 0, 0),
        ("error_after", "source", 1, 0),
        ("auto", "backup", 1, 60),
    ]:
        before, _ = metrics()
        status, body = request_http("/v1/chat/completions", {
            "model": mode, "stream": True, "stream_options": {"include_usage": True},
            "messages": [{"role": "user", "content": "test"}]})
        after, text = metrics()
        delta = {name: {field: after.get(name, {}).get(field, 0) -
                       before.get(name, {}).get(field, 0) for field in ["count", "sum"]}
                 for name in ["source", "backup"]}
        actual = delta[backend]
        ok = status == 200 and actual["count"] == count and actual["sum"] >= minimum
        if mode.startswith("error"):
            ok = ok and "injected_error" in body and "[DONE]" not in body
        else:
            ok = ok and "[DONE]" in body
        if mode == "auto":
            ok = ok and "alpha" in body and delta["source"]["count"] == 0
        ok = ok and "validated request" in text
        RESULTS.append({"name": "wire.ttft." + mode, "status": "PASS" if ok else "FAIL",
                        "http_status": status, "metrics_delta": delta,
                        "body": body, "metrics": text})
    result = {"assertions": RESULTS, "summary": {
        "total": len(RESULTS), "passed": sum(r["status"] == "PASS" for r in RESULTS),
        "failed": sum(r["status"] == "FAIL" for r in RESULTS)}}
    (WORK / "wire-results.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["summary"]))
    assert result["summary"]["failed"] == 0, result
finally:
    gateway.terminate()
    try:
        gateway.wait(timeout=5)
    except subprocess.TimeoutExpired:
        gateway.kill()
        gateway.wait()
    log.close()
    provider.shutdown()
    provider.server_close()
    thread.join()
